/**
 * @file restaraunt.cpp
 * @brief Realization of Restaraunt class
 */

#include "route.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
Route::Route() = default;

Route::Route(std::string Start_, std::string End_, double Length_, std::string Transport_, std::string id_) {
    Start = Start_;
    End = End_;
    Length = Length_;
    Transport = Transport_;
    id = id_;
}

void Route::print() {
    std::cout << "Start = " << Start << std::endl
        << "End = " << End << std::endl
        << "Length = " << Length << std::endl
       << " Transport= " << Transport << std::endl;
    //std::cout << std::endl;
}


std::string Route::getID(std::string Start, std::string End) {
    std::string result = "<route><";
    int temp = std::rand();
    result += std::to_string(temp);
    result += "><" + Start.substr(0, 1);
    result += End.substr(0, 2) + ">";

    return result;
}