/**
 * @file client.cpp
 * @brief Client realisation
 *
 * Realisation of a client to work with restaraunt JSON data remotely.
 *
 */

#include "httplib.h"
#include <iostream>
#include "nlohmann/json.hpp"

using namespace std;

const int SLEEP = 500;

int main() {
    // HTTP
    httplib::Client cli("localhost", 8080);

    int com_number = 0;
    bool exit = false;
    while (!exit) {
        std::cout << "Available commands : " << std::endl;
        std::cout << "0. Exit" << std::endl;
        std::cout << "1. Generate data.json file" << std::endl;
        std::cout << "2. Print data.json file" << std::endl;
        std::cout << "3. Execute" << std::endl;
        std::cout << "4. Add" << std::endl;
        std::cout << "5. Find" << std::endl;
        std::cout << "6. Delete" << std::endl;
        std::cout << "Enter the number of command : ";
        std::cin >> com_number;
        if (com_number < 0 || com_number > 6) {
            std::cout << "error : wrong command number" << std::endl << std::endl;
            continue;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));

        switch (com_number) {
        case 0:
        {
            exit = true;
            int exitS = -1;
            std::cout << "Do you want to kill the server process?" << std::endl;
            std::cout << "'0' - Yes" << std::endl;
            std::cout << "'1' No" << std::endl;
            std::cin >> exitS;
            if (exitS == 0) {
                auto res = cli.Post("/shutdown");
                if (res && res->status == 200) {
                    std::cout << "Successfully killed server" << std::endl;
                }
                else {
                    std::cout << "Failed to kill server.E rror status :  " << res->status << std::endl;
                }
            }
            break;
        }
        case 1:
        { int n;
        std::cout << "Enter the number the route to generate : " << std::endl;
        std::cin >> n;
        if (n <= 0) {
            std::cout << "error : number the route to generate less than zero" << std::endl; break;
        }
        std::string req = "/generate?count=" + std::to_string(n);
        std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
        auto res = cli.Post(req.c_str());
        if (res && res->status == 200) {
            std::cout << "Successfully generated " << n << " route" << std::endl;
        }
        else {
            std::cout << "Failed to generate route" << std::endl;
            std::cout << "error : " << res.error() << std::endl;
            std::cout << "status : " << res->status << std::endl;
        }
        break;
        }
        case 2:
        {
            auto res = cli.Get("/print");
            std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
            if (res && res->status == 200) {
                std::cout << "data.json :" << std::endl;
                nlohmann::json response_json = nlohmann::json::parse(res->body);
                std::cout << std::setw(4) << response_json << std::endl;
            }
            else {
                std::cout << "Failed to print" << std::endl;
                std::cout << "error : " << res.error() << std::endl;
                std::cout << "status : " << res->status << std::endl;
            }
            break;
        }
        case 3:
        {
            std::string type;
            std::cout << "Enter the type of transport : ";
            std::cin >> type;
            std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
            auto res = cli.Post("/execute", type, "text/plain");
            if (res && res->status == 200) {
                std::cout << "Successfully executed" << std::endl;
            }
            else {
                std::cout << "Failed to execute function" << std::endl;
                std::cout << "error status : " << res->status << std::endl;
            }
            break;
        }
         case 4:
        {
            std::string Start, End, Transport;
            double Length;
            std::cout << "Enter route name : ";
            std::cin >> Start >> End >> Transport >> Length;
            std::string req = "/add?Start=" + Start + "&End=" + End  + "&Transport=" + Transport+"&Length=" + std::to_string(Length);
            std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
            auto res = cli.Post(req.c_str());
            if (res && res->status == 200) {
                std::cout << "Added successfully" << std::endl;
            }
            else {
                std::cout << "Failed to add a new route" << std::endl;
                std::cout << "error status : " << res->status << std::endl;
            }

            break;
        }
         case 5:
         {
             std::string ID;
             std::cout << "Enter ID : " << std::endl;
             std::cin >> ID;

             std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
             auto res = cli.Post("/find", ID, "text/plain");
             if (res && res->status == 200) {
                 std::cout << "Successfully found" << std::endl;
             }
             else {
                 std::cout << "Failed to find a route" << std::endl;
                 std::cout << "error status : " << res->status << std::endl;
             }
             break;
         }
         case 6:
         {
             std::string Start, End;
             std::cout << "Enter route start and end: ";
             std::cin >> Start >> End ;
             std::string req = "/delete?Start=" + Start + "&End=" + End ;
             std::this_thread::sleep_for(std::chrono::milliseconds(SLEEP));
             auto res = cli.Post(req.c_str());
             if (res && res->status == 200) {
                 std::cout << "Deleted successfully" << std::endl;
             }
             else {
                 std::cout << "Failed to  delete" << std::endl;
                 std::cout << "error status : " << res->status << std::endl;
             }
             break;
         }
         default: std::cout << "There is no such command" << std::endl; break;
        }
    }

    return 0;
}