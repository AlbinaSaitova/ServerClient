
/**
 * @file reg.cpp
 * @brief Realization of reg class
 */

#include "reg.h"

bool reg::check(std::string str) {
	std::regex str_regex("(<route><\\d+><([A-Z]|[a-z])+>)");
	std::smatch match;
	//return std::regex_match(str, id_regex);
	return std::regex_match(str, match, str_regex);
}

/*bool reg::check(std::string str) {
    std::regex str_regex{ R"(<route><\\d+><([A-Z]|[a-z])+>)" };
    std::smatch match;
    //return std::regex_match(str, id_regex);
    return std::regex_match(str, match, str_regex);
}*/