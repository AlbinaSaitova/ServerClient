/**
 * @file server.cpp
 * @brief Server realisation
 *
 * Realisation of a server to work with restaraunt JSON data remotely.
 *
 */

#include <csignal>

#include "myjson.h"
#include "generator.h"
#include "httplib.h"
#include "reg.h"



void print(const httplib::Request&, httplib::Response&, myjson&);
void generate(const httplib::Request& req, httplib::Response& res, myjson& data, Generator& gen);
void d_elete(const httplib::Request&, httplib::Response&, myjson&);
void add(const httplib::Request&, httplib::Response&, myjson&, Generator&);
void execute(const httplib::Request&, httplib::Response&, myjson&, Generator&);
void find(const httplib::Request& req, httplib::Response& res, myjson& data);
void save(const httplib::Request&, httplib::Response&, myjson&);

int main()
{
    if (!reg::check("<route><24464><CNa>")) {
      //return -1;
    }
    
    //return 5;

    myjson data;
    Generator gen;
    gen.readFiles("C:/Users/User/source/repos/NEW_SERVER_CLIENT/last_build/Debug/Cities.txt", "C:/Users/User/source/repos/NEW_SERVER_CLIENT/last_build/Debug/Transport.txt");

    // HTTP
    httplib::Server server;

    server.Post("/generate", [&](const httplib::Request& req, httplib::Response& res) {
        generate(req, res, data, gen);
        });

    server.Get("/print", [&](const httplib::Request& req, httplib::Response& res) {
        std::cout << "print request reveived" << std::endl;
        print(req, res, data);
        std::cout << "finished" << std::endl;
        });

    server.Post("/execute", [&](const httplib::Request& req, httplib::Response& res) {
        std::cout << "execute request reveived" << std::endl;
        execute(req, res, data, gen);

        std::cout << "finished" << std::endl;
        });
    server.Post("/find", [&](const httplib::Request& req, httplib::Response& res) {
        std::cout << "find" << std::endl;
        find(req, res, data);
        std::cout << "finished" << std::endl;
        });

     server.Post("/delete", [&](const httplib::Request& req, httplib::Response& res) {
         std::cout << "delete request reveived" << std::endl;
         d_elete(req, res, data);
         std::cout << "finished" << std::endl;
         });

    server.Post("/add", [&](const httplib::Request& req, httplib::Response& res) {
              std::cout << "add request received" << std::endl;
              add(req, res, data, gen);
              std::cout << "finished" << std::endl;
    });

    std::cout << "server started" << std::endl;

    server.listen("localhost", 8080);

    return 0;
}

void generate(const httplib::Request& req, httplib::Response& res, myjson& data, Generator& gen) {
    std::cout << res.status << std::endl;
    std::string  n = req.get_param_value("count");
    std::cout << res.status << std::endl;
    int count = std::stoi(n);

    std::cout << "generating " << count << " restaraunts" << std::endl;
    gen.generate("data.json", count, data);
    data.Clear();
    FILE* fin = fopen("data.json", "r");
    data.Input(fin);

    std::cout << "finished " << std::endl;
}

void print(const httplib::Request&, httplib::Response& res, myjson& data) {
    res.set_content(data.Dump(), "json");


}

void d_elete(const httplib::Request& req, httplib::Response&, myjson& data) {
    std::string Start = req.get_param_value("Start");
    std::string End = req.get_param_value("End");
    data.Delete(Start, End);
}
void execute(const httplib::Request& req, httplib::Response&, myjson& data, Generator& gen) {
    std::string type = req.body;
    data.Execute(type);
}
void find(const httplib::Request& req, httplib::Response& res, myjson& data) {
    std::string id = req.body;
    if (!reg::check(id)) {
        res.status = 400;
        return;
    }
    json resJson = data.Find(id);
    if (resJson == json({})) {
        res.status = 404;
        return;
    }
    else {
        res.status = 200;
        return;
    }
}

void add(const httplib::Request& req, httplib::Response&, myjson& data, Generator& gen) {
    std::string Start = req.get_param_value("Start");
    std::string End = req.get_param_value("End");
    std::string Transport = req.get_param_value("Transport");
    std::string n = req.get_param_value("Length");
    double Length = std::stoi(n);
    data.Add(Start, End, Transport, Length);
}


