/**
 * @file myjson.cpp
 * @brief Realization of myjson class
 */

#include "myjson.h"
#include <fstream>
#include <iostream>
#include <string>
myjson::myjson() {
    ObjJson = json({});
}

myjson::myjson(char* str) {
    ObjJson = json::parse(str);
}

/*myjson::myjson(FILE* fin) {
    Input(fin);
}*/

/*void myjson::Input(FILE* fin) {
    ObjJson = json::parse(fin);
}*/
void myjson::Input(std::fstream& FileInput, std::string str) {
    FileInput.open(str);
    FileInput >> ObjJson;
}
void myjson::Print() {
    std::string temp = ObjJson.dump(2);
    std::cout << temp << std::endl;
}

void myjson::Print(json data) {
    std::string temp = data.dump(2);
    std::cout << temp << std::endl;
}
void myjson::Execute(std::string type) {
    size_t n = ObjJson["Route"].size(), i;
    int res, Length;
    std::string Start, End;

    for (i = 0; i < n; i++) {

        std::string str_inp1(ObjJson["Route"][i]["Transport"]);
        res = type.compare(str_inp1);
        std::cout << res << std::endl;
        if (res == 0) {

            Start = ObjJson["Route"][i]["Start"];
            End = ObjJson["Route"][i]["End"];
            Length = ObjJson["Route"][i]["Length"];

            out = {
            {"Start", Start },
            {"End", End},
            {"Length", Length}
            };

        }
    }
    std::cout << out << std::endl;
}


void myjson::Add(std::string Start, std::string End, std::string Transport, double Length) {

    std::string responseString = R"({"Start":"Moscow","End":"Kazan","Length": 717 , "Transport":"Plane",  "ID":"<route><26500><CRo>"})";
    json responseJson = json::parse(responseString);
    responseJson["Start"] = Start;
    responseJson["End"] = End;
    responseJson["Transport"] = Transport;
    responseJson["Length"] = Length;
    std::string id = Route::getID(Start, End);
    responseJson["ID"] = id;
    int n = ObjJson["Route"].size(); 
    ObjJson["Route"][n] = responseJson;
}
void myjson::Delete(std::string Start, std::string End) {

    size_t n = ObjJson["Route"].size(), i;
    int res1, res2;
    for (i = 0; i < n; i++) {
        std::string str_inp1(ObjJson["Route"][i]["Start"]);
        std::string str_inp2(ObjJson["Route"][i]["End"]);

        res1 = Start.compare(str_inp1);
        res2 = End.compare(str_inp2);
        if (res1 == 0 && res2 == 0) {
            ObjJson["Route"][i].erase("Start");
            ObjJson["Route"][i].erase("End");
            ObjJson["Route"][i].erase("Transport");
            ObjJson["Route"][i].erase("Length");
            ObjJson["Route"][i].erase("ID");
        }
    }


}
void myjson::Input(FILE* fin) {
    ObjJson = json::parse(fin);
}

void myjson::Clear() {
    ObjJson.clear();
}


std::string myjson::Dump() {
    return ObjJson.dump(4, ' ');
}
json myjson::Find(std::string id) {
    std::string Start;
    std::string End;
    double Length;
    std::string Transport;
    int check;

    for (int i = 0; i < ObjJson["Route"].size(); i++) {
        std::cout << ObjJson["Route"][i]["ID"] << std::endl;
        std::string str_inp1(ObjJson["Route"][i]["ID"]);
        check = id.compare(str_inp1);
        std::cout << check << std::endl;
        if (check == 0) {
            json resJson;
            resJson["Route"][i]["Srart"] = ObjJson["Route"][i]["Srart"];
            resJson["Route"][i]["End"] = ObjJson["Route"][i]["End"];
            resJson["Route"][i]["Transport"] = ObjJson["Route"][i]["Transport"];
            resJson["Route"][i]["Length"] = ObjJson["Route"][i]["Length"];
            resJson["Route"][i]["ID"] = id;
            myjson::Print(resJson);
            return resJson;
        }

    }
    return nlohmann::json({});
}
