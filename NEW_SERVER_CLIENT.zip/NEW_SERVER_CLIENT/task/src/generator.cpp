/**
 * @file generator.cpp
 * @brief Realization of Generator class
 */

#include "generator.h"

#include <iostream>
#include <string>
#include <regex>
#include <fstream>

 
void Generator::generate(std::string fname, int n, myjson& data) {
	std::string temp1, temp2, temp3, id;
	double Length;
	std::fstream FileOutput;
	FileOutput.open(fname);
	for (int i = 0; i < n; i++) {

		temp1 = Cities[std::rand() % Cities.size()];
		temp2 = Cities[std::rand() % Cities.size()];
		temp3 = Transports[std::rand() % Transports.size()];
		Length = std::rand();
		data.Add(temp1, temp2, temp3, Length);
	}
	std::string temp = data.ObjJson.dump(2);
	FileOutput << temp << std::endl;
	FileOutput.close();
}


void Generator::readFiles(std::string cities, std::string transport) {

	std::ifstream city(cities);
	std::ifstream trans(transport);
	std::string word;
	Cities.clear();
	Transports.clear();

	while (std::getline(city, word)) {
		Cities.push_back(word);
	}
	while (std::getline(trans, word)) {
		Transports.push_back(word);
	}

	city.close();
	trans.close();
}

