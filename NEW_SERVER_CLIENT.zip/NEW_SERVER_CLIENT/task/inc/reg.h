/**
 * @file reg.h
 * @brief Header file for the reg class.
 */


#include <regex>
#include <iostream>
#include <string>
#include <regex>
#include <fstream>
 /**
  * @class reg
  * @brief A class to check the validity of route IDs.
  */
class reg {
     private:
    /**
     * @brief Default constructor.
     */
    reg();
    public:
    /**
    * @brief Check the validity of route IDs.
    */

    static bool check(std::string);
};

