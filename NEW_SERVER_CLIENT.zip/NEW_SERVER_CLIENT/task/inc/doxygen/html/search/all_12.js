var searchData=
[
  ['unflatten_0',['unflatten',['../classbasic__json.html#a96b7bb2b2c087a2dec6586dafa84154c',1,'basic_json']]],
  ['update_1',['update',['../classbasic__json.html#aaaefc092c0976d3499cfdd74d6767ab5',1,'basic_json::update(const_reference j, bool merge_objects=false)'],['../classbasic__json.html#aac44bc3859374088d469a7ea95d5bd19',1,'basic_json::update(const_iterator first, const_iterator last, bool merge_objects=false)']]]
];
