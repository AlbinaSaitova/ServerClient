var searchData=
[
  ['initializer_5flist_5ft_0',['initializer_list_t',['../classbasic__json.html#a7d5145f36ef33d33ac3baa5720fde4c8',1,'basic_json']]],
  ['iterator_1',['iterator',['../classbasic__json.html#a241744e725625710e8b9c1f9949fabda',1,'basic_json']]]
];
