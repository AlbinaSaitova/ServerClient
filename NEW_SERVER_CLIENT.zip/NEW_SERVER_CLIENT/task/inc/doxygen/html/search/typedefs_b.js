var searchData=
[
  ['size_5ftype_0',['size_type',['../classbasic__json.html#a56d05aae2d1773cedb888ae8ed576caf',1,'basic_json']]],
  ['string_5ft_1',['string_t',['../classbasic__json.html#a413818018f56cc0d49824c51bc5a2986',1,'basic_json']]]
];
