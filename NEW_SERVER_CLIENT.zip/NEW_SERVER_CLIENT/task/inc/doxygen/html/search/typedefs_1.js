var searchData=
[
  ['binary_5ft_0',['binary_t',['../classbasic__json.html#aeee5b298a04a26345d7ac50544e25270',1,'basic_json']]],
  ['boolean_5ft_1',['boolean_t',['../classbasic__json.html#aa0c69a44d0bc75ccefbb819b073c35f1',1,'basic_json']]]
];
