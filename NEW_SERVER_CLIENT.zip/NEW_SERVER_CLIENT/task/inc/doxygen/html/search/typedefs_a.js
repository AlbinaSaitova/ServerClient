var searchData=
[
  ['reference_0',['reference',['../classbasic__json.html#a2c0abb2061a06bcf3365b950b5b6652d',1,'basic_json']]],
  ['reverse_5fiterator_1',['reverse_iterator',['../classbasic__json.html#ab1d35636780e71c7caf3564cd0da5398',1,'basic_json']]]
];
