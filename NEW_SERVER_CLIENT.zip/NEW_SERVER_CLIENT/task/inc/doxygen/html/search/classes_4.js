var searchData=
[
  ['myjson_0',['myjson',['../structmyjson.html',1,'']]]
];
