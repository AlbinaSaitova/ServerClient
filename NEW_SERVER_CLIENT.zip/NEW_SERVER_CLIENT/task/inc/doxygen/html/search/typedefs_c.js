var searchData=
[
  ['value_5ftype_0',['value_type',['../classbasic__json.html#a1e99bba991ec9ca8bdb97fc2cc70084f',1,'basic_json']]]
];
