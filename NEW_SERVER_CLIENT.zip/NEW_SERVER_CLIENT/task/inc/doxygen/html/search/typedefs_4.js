var searchData=
[
  ['error_5fhandler_5ft_0',['error_handler_t',['../classbasic__json.html#a9db0beee6244e31b626377450a4ae6fa',1,'basic_json']]]
];
