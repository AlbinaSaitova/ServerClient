var searchData=
[
  ['basic_5fjson_0',['basic_json',['../classbasic__json.html',1,'']]]
];
