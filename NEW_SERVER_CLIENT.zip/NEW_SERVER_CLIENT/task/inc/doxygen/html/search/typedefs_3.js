var searchData=
[
  ['default_5fobject_5fcomparator_5ft_0',['default_object_comparator_t',['../classbasic__json.html#a911f62c4a1d49b8c64ef9b20e090fb32',1,'basic_json']]],
  ['difference_5ftype_1',['difference_type',['../classbasic__json.html#a57b8d22262b572ae8bc3529c47b61470',1,'basic_json']]]
];
