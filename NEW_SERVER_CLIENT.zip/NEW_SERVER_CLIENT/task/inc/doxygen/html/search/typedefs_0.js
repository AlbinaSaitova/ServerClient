var searchData=
[
  ['allocator_5ftype_0',['allocator_type',['../classbasic__json.html#a2960afbac7aab0e6f3fb02199c76862b',1,'basic_json']]],
  ['array_5ft_1',['array_t',['../classbasic__json.html#a2633e83ba602f57fe99ce2443765e523',1,'basic_json']]]
];
