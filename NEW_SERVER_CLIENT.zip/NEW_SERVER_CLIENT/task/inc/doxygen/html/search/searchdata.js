var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuv~",
  1: "bghlmr",
  2: "gmr",
  3: "abcdefgimoprstuv~",
  4: "eilmst",
  5: "abcdeijnoprsv",
  6: "os",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Pages"
};

