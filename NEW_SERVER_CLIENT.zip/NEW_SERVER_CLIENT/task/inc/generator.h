/**
 * @file generator.h
 * @brief Header file for the Generator class.
 */

#include "route.h"
#include "myjson.h"

#include <stdio.h>
#include <fstream>
#include <ctime>


 /**
  * @class Generator
  * @brief This class generates random Route objects using the data read from files.
  */
class Generator {
private:



	/** The vector of city names. */
	std::vector<std::string> Cities;

	/** The vector of transport names. */
	std::vector<std::string> Transports;
public:


	/**
	 * @brief Generates random Routs.
	 * @param fname The file to write the generated Routs.
	 * @param n The number of Routs to generate.
	 */
	void generate(std::string fname, int n, myjson& data);
	/**
	 * @brief Reads data from files.
	 * @param cities The text file from which the names of cities are read.
	 * @param transport The text file from which the kinds of transport are read.
	 */
	void readFiles(std::string cities, std::string transport);
};

