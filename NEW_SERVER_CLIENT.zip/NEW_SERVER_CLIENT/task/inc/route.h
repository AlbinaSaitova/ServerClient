#pragma once
/**
*
 * @file route.h
 * @brief Header file for the Route struct.
 */
 /**
  * @file route.h
  * @briefHeader file for the Route struct.
  */
#include <iostream>
#include <vector>
#include <algorithm>

 /**
  * @brief The Route struct represents a route  with the specified start, end and length.
  */
struct Route {

    /**The ID of the route*/
    std::string id;
    /**The start of the route*/
    std::string Start;
    /**The end of the route*/
    std::string End;
    /**The length of the route*/
    double Length;
    /**Type of transport for traveling along the route*/
    std::string Transport;


    /**
     * @brief Default constructor for Restaraunt.
     */
    Route();

    /**
     *@brief Constructor for Restaraunt.
     *@param Start_ The start of the route.
     *@param End_ The end amount of the route.
     *@param Length_ The length of the route.
     *@param Transport_ The transport of the route.
     *@param id_ The id of the route.
     */
    Route(std::string Start_, std::string End_, double Length_, std::string Transport_, std::string id_);

    /**
     *@brief Print the details of the route
     */
    void print();
    /**
    *@brief Generate ID of the route.
    *@param Start The start of the route
    *@param End The end of the route
    *@return The ID of the route
    */
    static std::string getID(std::string Start, std::string End);
};



