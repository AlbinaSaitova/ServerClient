#pragma once
/**
 * @file myjson.h
 * @brief Contains the definition of the myjson class for handling JSON data.
 *
 * This class provides methods for reading data , manipulating the data stream in JSON format.
 */
#include <stdio.h>
#include <fstream>
#include "nlohmann/json.hpp"
#include "route.h"

using json = nlohmann::json;

/**
 * @class myjson
 * @brief Handles JSON data for manipulating route .
 */

struct myjson{

    json ObjJson;
    json out;
    /**
    * @brief Default constructor.
    */
    myjson();
    /**
   * @brief Constructor for myjson that takes a json in string format as an argument.
   * @param json_string The JSON file name in string format.
   */
    myjson(char*);
    //myjson(FILE*);
       /**
     * @brief Reads input from the specified file stream into the JSON data.
     * @param[in] file The file stream containing the JSON data.
     */
    void Input(std::fstream& FileInput, std::string str);
    void Input(FILE* fin);
    /**
    * @brief Prints the JSON data to the console.
    */
    void Print();
    void Print(json data);
    //void Print(std::fstream& FileInput);
     /**
     * @brief Finds the route with the specified id in the JSON data.
     * @param[in] id The id of the route to find.
     */
    json Find(std::string id);
     /**
     * @brief Searches for routes with the specified type of transport.
     * @param[in] type The type of transport.
     */
    void Execute(std::string type);
    /**
    * @brief Adds a route to the JSON data.
    * @param[in] Start The start of the route.
    * @param[in] End The end of the route.
    * @param[in] Transport The transport of the route.
    * @param[in] Length The length of the route.
    */
    void Add(std::string Start, std::string End, std::string Transport, double Length);
    /**
    * @brief Generates n routes.
    * @param[in] n The numbers of route.
    * @param[in] fname The file  name.
    */
    void generate(int n, std::string fname);

    //void Delete(std::string);
     /**
    * @brief Delete the route.
    * @param[in] Start The start of the route.
    * @param[in] End The end of the route.
    */
    void Delete(std::string Start, std::string End);
    /**
    * @brief Crear JSON structure.
    */
    void Clear();
    /**
  * @brief Dumps the JSON data to a string.
  * @return A string representation of the JSON data.
  */
    std::string Dump();

};